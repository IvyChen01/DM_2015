<?php

function xs_form_shortcode($atts, $content) {
    extract(shortcode_atts(array(
        'inline_form' => '0',

                    ), $atts));

    $inline_form = ($inline_form) ? ' ABss_inline_form' : '';

    static $form_number = 0;
    $form_number++;
    $form_id = 'xs_form_' . $form_number;

    $return = '
        <div class="col-sm-10 col-sm-offset-1"><div class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="500ms">
                <form id="' . $form_id . '" class="ABss_form' . $inline_form . ' newsletter-form" action="#" method="post">
            <p><input name="xs_subscriber_email" class="xs_subscriber_email" placeholder="Your Email Address"></p>
            <p><button type="submit" class="btn btn-default">Subscribe</button></p>';

    $return .= '
                <input type="hidden" name="ajaxnonce" value="' . wp_create_nonce($form_id) . '">
                <input type="hidden" name="formno" value="' . $form_number . '">
        </form>
        <div class="xs_success_message text-center"><h2></h2></div>
</div></div>';

    return $return;
}

add_shortcode('doors-newslatter', 'xs_form_shortcode');

function xs_scripts() {
    wp_enqueue_style('xs_subs_ss_form_style', plugins_url() . '/xs-subscribe/css/xs-subscribe.css', false, '1.0.1');

    wp_enqueue_script('xs_subs__placeholder', plugins_url() . '/xs-subscribe/js/jquery.placeholder.js', array('jquery'), '2.0.7', true);
    wp_enqueue_script('xs_ajax_subscribe', plugins_url() . '/xs-subscribe/js/xs-subscribe.js', array('jquery', 'xs_subs__placeholder'), '1.0.1', true);
    wp_localize_script('xs_ajax_subscribe', 'ABss_custom', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'success' => __('You have successfully subscribed. Thank you!', 'xs'),
        'error' => __('Valid Email is Required', 'xs'),
    ));
}

add_action('wp_enqueue_scripts', 'xs_scripts');
