<?php if(!defined('VIEW')) exit(0); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
[15:38:43 127.0.0.1]	[admin][db] time: 0.024<br />
[15:38:44 127.0.0.1]	[admin][db] time: 0.019<br />
